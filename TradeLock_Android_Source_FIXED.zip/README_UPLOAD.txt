TradeLock - Android source project

This ZIP contains the Android Studio project in the TradeLock_Android/ folder.
It is source code, not an APK.

For the GitHub Actions workflow, create this file in your repository:
.github/workflows/android.yml

The workflow must unzip TradeLock_Android_Source.zip into a folder named source,
then run: gradle -p source/TradeLock_Android assembleDebug

Important: this is an initial prototype and has not yet been successfully built
or tested on a physical device. Accessibility-based blocking is not tamper-proof.
