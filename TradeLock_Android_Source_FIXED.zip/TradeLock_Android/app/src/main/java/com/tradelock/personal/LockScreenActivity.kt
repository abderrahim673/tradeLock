package com.tradelock.personal

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class LockScreenActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var countdown: TextView
    private val tick = object : Runnable {
        override fun run() {
            val until = getSharedPreferences("tradelock", MODE_PRIVATE)
                .getLong("lock_until_utc_ms", 0L)
            val remaining = until - System.currentTimeMillis()
            if (remaining <= 0L) {
                getSharedPreferences("tradelock", MODE_PRIVATE).edit()
                    .putLong("lock_until_utc_ms", 0L).apply()
                finish()
                return
            }
            val totalSeconds = remaining / 1000L
            val h = totalSeconds / 3600
            val m = (totalSeconds % 3600) / 60
            val s = totalSeconds % 60
            countdown.text = String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s)
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(0xFF101820.toInt())
        }
        root.addView(TextView(this).apply {
            text = "TRADELOCK"
            textSize = 30f
            setTextColor(0xFFFFC857.toInt())
        })
        root.addView(TextView(this).apply {
            text = "وقت الراحة"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 24, 0, 8)
        })
        countdown = TextView(this).apply {
            textSize = 42f
            setTextColor(0xFFFFFFFF.toInt())
        }
        root.addView(countdown)
        root.addView(TextView(this).apply {
            text = "سيُسمح بفتح MetaTrader 5 عند إغلاق شمعة M15 التالية."
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFFCCCCCC.toInt())
            setPadding(0, 24, 0, 0)
        })
        setContentView(root)
        window.setStatusBarColor(0xFF101820.toInt())
        window.setNavigationBarColor(0xFF101820.toInt())
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // The accessibility service will re-show this screen if MT5 is foregrounded while locked.
        moveTaskToBack(true)
    }
}
