package com.tradelock.personal

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("tradelock", MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var offsetInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "TradeLock"
            textSize = 30f
        })
        layout.addView(TextView(this).apply {
            text = "قفل MetaTrader 5 حتى إغلاق شمعة M15 التالية"
            textSize = 16f
            setPadding(0, 16, 0, 24)
        })

        layout.addView(TextView(this).apply {
            text = "فرق توقيت سيرفر Exness عن UTC بالساعات"
            textSize = 14f
        })
        offsetInput = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_SIGNED or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(prefs.getFloat("server_offset_hours", 2f).toString())
            hint = "مثال: 2 أو 3"
        }
        layout.addView(offsetInput)

        val saveOffset = Button(this).apply {
            text = "حفظ فرق التوقيت"
            setOnClickListener {
                val v = offsetInput.text.toString().toFloatOrNull()
                if (v == null || v !in -12f..14f) {
                    Toast.makeText(this@MainActivity, "أدخل فرق توقيت صحيحاً", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit().putFloat("server_offset_hours", v).apply()
                    Toast.makeText(this@MainActivity, "تم حفظ فرق التوقيت", Toast.LENGTH_SHORT).show()
                }
            }
        }
        layout.addView(saveOffset)

        val accessibility = Button(this).apply {
            text = "تفعيل صلاحية مراقبة التطبيقات"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(accessibility)

        val endSession = Button(this).apply {
            text = "أنهيت جلسة التداول"
            textSize = 18f
            setOnClickListener {
                val offset = prefs.getFloat("server_offset_hours", 2f).toDouble()
                val unlockAt = nextM15CloseUtc(System.currentTimeMillis(), offset)
                prefs.edit().putLong("lock_until_utc_ms", unlockAt).apply()
                val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                fmt.timeZone = TimeZone.getDefault()
                status.text = "تم تفعيل القفل. موعد السماح المتوقع حسب توقيت الهاتف: ${fmt.format(Date(unlockAt))}"
                Toast.makeText(this@MainActivity, "تم تفعيل فترة الراحة", Toast.LENGTH_LONG).show()
            }
        }
        layout.addView(endSession)

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 24, 0, 12)
        }
        layout.addView(status)
        layout.addView(TextView(this).apply {
            text = "مهم: أدخل فرق توقيت سيرفر Exness الصحيح. هذا النموذج لا يجلب توقيت السيرفر تلقائياً، وقد يتغير الفرق حسب توقيت الوسيط الصيفي/الشتوي."
            textSize = 13f
            setPadding(0, 18, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(layout) })
        refreshStatus()
    }

    private fun refreshStatus() {
        val until = prefs.getLong("lock_until_utc_ms", 0L)
        status.text = if (until > System.currentTimeMillis()) {
            "القفل نشط حتى: ${Date(until)}"
        } else "لا توجد فترة قفل نشطة."
    }

    private fun nextM15CloseUtc(nowUtcMs: Long, offsetHours: Double): Long {
        val offsetMs = (offsetHours * 3_600_000.0).toLong()
        val serverNow = nowUtcMs + offsetMs
        val interval = 15L * 60_000L
        // Always choose the next close boundary, including when pressed exactly on a boundary.
        val nextServerBoundary = (Math.floorDiv(serverNow, interval) + 1L) * interval
        return nextServerBoundary - offsetMs
    }
}
