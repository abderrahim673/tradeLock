package com.tradelock.personal

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class Mt5GuardService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg != "net.metaquotes.metatrader5") return

        val prefs = getSharedPreferences("tradelock", MODE_PRIVATE)
        val lockUntil = prefs.getLong("lock_until_utc_ms", 0L)
        if (System.currentTimeMillis() < lockUntil) {
            val intent = Intent(this, LockScreenActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            startActivity(intent)
        } else if (lockUntil != 0L) {
            prefs.edit().putLong("lock_until_utc_ms", 0L).apply()
        }
    }

    override fun onInterrupt() {}
}
